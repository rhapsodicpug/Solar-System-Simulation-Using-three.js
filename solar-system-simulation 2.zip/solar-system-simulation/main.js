const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

const light = new THREE.PointLight(0xffffff, 2, 100);
light.position.set(0, 0, 0);
scene.add(light);

const sunGeometry = new THREE.SphereGeometry(3, 32, 32);
const sunMaterial = new THREE.MeshBasicMaterial({ color: 0xFDB813 });
const sun = new THREE.Mesh(sunGeometry, sunMaterial);
scene.add(sun);

const planetData = [
  { name: "earth", texture: "textures/earth.jpg", distance: 10, size: 1, speed: 0.01 },
  { name: "mars", texture: "textures/mars.jpg", distance: 14, size: 0.8, speed: 0.008 }
];

const planets = [];
const loaders = {};

planetData.forEach(data => {
  loaders[data.name] = new THREE.TextureLoader().load(data.texture);
  const geometry = new THREE.SphereGeometry(data.size, 32, 32);
  const material = new THREE.MeshStandardMaterial({ map: loaders[data.name] });
  const mesh = new THREE.Mesh(geometry, material);
  scene.add(mesh);
  planets.push({ mesh, angle: 0, ...data });
});

camera.position.z = 30;

const clock = new THREE.Clock();
let paused = false;

function animate() {
  requestAnimationFrame(animate);
  if (!paused) {
    const delta = clock.getDelta();
    planets.forEach(p => {
      p.angle += p.speed;
      p.mesh.position.x = Math.cos(p.angle) * p.distance;
      p.mesh.position.z = Math.sin(p.angle) * p.distance;
    });
  }
  renderer.render(scene, camera);
}

animate();

document.getElementById("pauseBtn").addEventListener("click", () => {
  paused = !paused;
});

document.getElementById("darkModeToggle").addEventListener("click", () => {
  document.body.classList.toggle("light-mode");
});